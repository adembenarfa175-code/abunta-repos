import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw
class App(Adw.Application):
    def do_activate(self):
        win = Adw.ApplicationWindow(application=self, title="abunta-installer-gui")
        win.set_content(Adw.StatusPage(title="Welcome to abunta-installer-gui", icon_name="package-x-generic"))
        win.present()
App(application_id='org.abunta.abunta-installer-gui').run(None)
