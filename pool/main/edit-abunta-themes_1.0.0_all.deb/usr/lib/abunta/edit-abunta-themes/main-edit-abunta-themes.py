import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

class AbuntaApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id='org.abunta.themes')
    def do_activate(self):
        win = Adw.ApplicationWindow(application=self)
        win.set_title("Abunta Theme Editor")
        win.set_default_size(400, 200)
        
        banner = Adw.StatusPage(
            title="Welcome to Abunta Themes",
            description="Customize your UI (GTK4 & QT) easily.",
            icon_name="preferences-desktop-theme"
        )
        win.set_content(banner)
        win.present()

app = AbuntaApp()
app.run(None)
