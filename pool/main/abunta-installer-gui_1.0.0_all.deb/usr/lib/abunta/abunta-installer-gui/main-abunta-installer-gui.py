import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw

class AbuntaApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id='org.abunta.installer')
    def do_activate(self):
        win = Adw.ApplicationWindow(application=self)
        win.set_title("Abunta Installer")
        win.set_default_size(400, 200)
        
        banner = Adw.StatusPage(
            title="Welcome to Abunta Installer",
            description="Preparing your Arixie system setup...",
            icon_name="system-software-install"
        )
        win.set_content(banner)
        win.present()

app = AbuntaApp()
app.run(None)
