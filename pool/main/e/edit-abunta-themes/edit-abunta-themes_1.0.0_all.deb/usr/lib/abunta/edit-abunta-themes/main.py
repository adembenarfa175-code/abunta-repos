import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw
class App(Adw.Application):
    def do_activate(self):
        win = Adw.ApplicationWindow(application=self, title="edit-abunta-themes")
        win.set_content(Adw.StatusPage(title="Welcome to edit-abunta-themes", icon_name="package-x-generic"))
        win.present()
App(application_id='org.abunta.edit-abunta-themes').run(None)
